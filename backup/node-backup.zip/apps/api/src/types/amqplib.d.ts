declare module 'amqplib';
